library(testthat)
test_check("streamgraph")
